package com.example.etrip1.pass

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.etrip1.R

@Composable
fun BuyPassScreen(navController: NavController? = null) {
    val context = LocalContext.current
    val passViewModel: PassViewModel = viewModel()

    // Theme colors
    val orangeColor = Color(0xFFFFA500)
    val blueColor = Color(0xFF1E88E5)
    val backgroundColor = Color(0xFFFFFDF7)

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .verticalScroll(scrollState)  // make it scrollable
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Logo at top-left
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.Start
        ) {
            Icon(
                painter = painterResource(id = R.drawable.logoo),
                contentDescription = "Bus Pass",
                tint = Color.Unspecified,
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
            )
        }

        // Title
        Text(
            text = "Buy a Bus Pass",
            style = MaterialTheme.typography.headlineSmall,
            color = orangeColor,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Subtitle
        Text(
            text = "Choose the right pass for your travel needs and save on trips!",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        // --- Pass Cards ---
        PassCard(
            title = "Daily Pass",
            price = "R20.00",
            trips = "3 trips",
            description = "Best for short-term travelers",
            buttonColor = blueColor,
            onBuyClick = {
                passViewModel.startPayment(
                    context,
                    amount = 20.00,
                    passType = "daily",
                    onUrlReady = { paymentUrl ->
                        val intent = Intent(context, PayFastWebViewActivity::class.java)
                        intent.putExtra("url", paymentUrl)
                        intent.putExtra("passType", "daily")
                        context.startActivity(intent)
                    },
                    onError = {}
                )
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        PassCard(
            title = "Weekly Pass",
            price = "R70.00",
            trips = "15 trips",
            description = "Most popular choice for regular riders",
            highlight = true,
            buttonColor = blueColor,
            onBuyClick = {
                passViewModel.startPayment(
                    context,
                    amount = 70.00,
                    passType = "weekly",
                    onUrlReady = { paymentUrl ->
                        val intent = Intent(context, PayFastWebViewActivity::class.java)
                        intent.putExtra("url", paymentUrl)
                        intent.putExtra("passType", "weekly")
                        context.startActivity(intent)
                    },
                    onError = {}
                )
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        PassCard(
            title = "Monthly Pass",
            price = "R250.00",
            trips = "60 trips",
            description = "Perfect for daily commuters",
            buttonColor = blueColor,
            onBuyClick = {
                passViewModel.startPayment(
                    context,
                    amount = 250.00,
                    passType = "monthly",
                    onUrlReady = { paymentUrl ->
                        val intent = Intent(context, PayFastWebViewActivity::class.java)
                        intent.putExtra("url", paymentUrl)
                        intent.putExtra("passType", "monthly")
                        context.startActivity(intent)
                    },
                    onError = {}
                )
            }
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Footer Note
        Text(
            text = "Note: All passes are valid only for the selected period and are non-transferable.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 12.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
fun PassCard(
    title: String,
    price: String,
    trips: String,
    description: String,
    buttonColor: Color,
    onBuyClick: () -> Unit,
    highlight: Boolean = false
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                if (highlight) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFFFA500))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "Popular",
                            color = Color.White,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = description, color = Color.Gray, style = MaterialTheme.typography.bodyMedium)

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "$price  •  $trips",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFF1E88E5),
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onBuyClick,
                colors = ButtonDefaults.buttonColors(containerColor = buttonColor),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Buy Now", color = Color.White)
            }
        }
    }
}

@Composable
@Preview(showBackground = true, showSystemUi = true)
fun BuyPassScreenPreview() {
    MaterialTheme {
        BuyPassScreen()
    }
}
